   <!-- footer -->
                  <div class="container-fluid">
                     <div class="footer">
                        <p>Copyright © 2023. All rights reserved.<br><br>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/jquery.min.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/popper.min.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/animate.js"></script>
      <!-- select country -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/Chart.min.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/Chart.bundle.min.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/utils.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="<?php echo e(url('/')); ?>/public/admin/js/custom.js"></script>
      <script src="<?php echo e(url('/')); ?>/public/admin/js/chart_custom_style1.js"></script>
   </body>
</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>