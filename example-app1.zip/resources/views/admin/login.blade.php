<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Pluto - Responsive Bootstrap Admin Panel Templates</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <!-- site icon -->
      <link rel="icon" href="{{  url('/'); }}/public/admin/images/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/colors.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/css/custom.css" />
      <!-- calendar file css -->
      <link rel="stylesheet" href="{{  url('/'); }}/public/admin/js/semantic.min.css" />
  
   </head>
   <body class="inner_page login">
      <div class="full_container">
         <div class="container">
            <div class="center verticle_center full_height">
               <div class="login_section">
                  <div class="logo_login">
                     <div class="center">
                        <img width="210" src="{{  url('/'); }}/public/admin/images/logo/logo.png" alt="#" />
                     </div>
                  </div>
                  <div class="login_form">

                     
                     <form method="post" action="{{'login'}}">
                            @csrf

                              @if (session()->has('success'))
                        <div class="alert alert-success">
                        @if(is_array(session()->get('success')))
                                <ul>
                                    @foreach (session()->get('success') as $message)
                                        <li>{{ $message }}</li>
                                    @endforeach
                                </ul>
                                @else
                                    {{ session()->get('success') }}
                                @endif
                            </div>
                        @endif
                         @if (count($errors) > 0)
                          @if($errors->any())
                            <div class="alert alert-danger" role="alert">
                              {{$errors->first()}}
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                              </button>
                            </div>
                          @endif
                        @endif
                        <fieldset>
                           <div class="field">
                              <label class="label_field">Email Address</label>
                              <input id="email" type="email" class="form-control" name="email" required>
                           </div>
                           <div class="field">
                              <label class="label_field">Password</label>
                              <input type="password" name="password" class="form-control" required/>
                           </div>
                           <div class="field margin_0">
                              <button type="submit" class="main_bt">Login</button>
                           </div>
                        </fieldset>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="{{  url('/'); }}/public/admin/js/jquery.min.js"></script>
      <script src="{{  url('/'); }}/public/admin/js/popper.min.js"></script>
      <script src="{{  url('/'); }}/public/admin/js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="{{  url('/'); }}/public/admin/js/animate.js"></script>
      <!-- select country -->
      <script src="{{  url('/'); }}/public/admin/js/bootstrap-select.js"></script>
      <!-- nice scrollbar -->
      <script src="{{  url('/'); }}/public/admin/js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="{{  url('/'); }}/public/admin/js/custom.js"></script>
   </body>
</html>