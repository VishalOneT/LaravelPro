@include('admin.layouts.header')

<div class="container">
    @yield('content')
</div>

@include('admin.layouts.footer')