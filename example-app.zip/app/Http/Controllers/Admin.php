<?php

namespace App\Http\Controllers;
use DB;
use Session;
use Illuminate\Http\Request;

class Admin extends Controller
{
    public function index()
    {
        return view('admin.login');
    }


     public function login(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        $adminLoginCheck = DB::table('admin')->where(array('useremail'=>$email,'userpassword'=>$password))->first();

            if($adminLoginCheck)
            {
                  if ($adminLoginCheck->useremail==$request->email) 
                  {
                    Session::put('bamaAdmin', $email);
                    Session::save();
                    return redirect('dashboard')->with('status', 'Login SuccessFully');
                  }
                  else
                  {
                    return redirect('admin')->withErrors('Wrong Password');
                  }
            }
            else
            {
              return redirect('admin')->withErrors('Email/Password Wrong');
            }

    }
    
    public function logout(Request $request)
    { 
        Session::forget('bamaAdmin');
        Session::flush();
      return redirect('admin')->withErrors('Wrong Password');
    }


    public function dashboard()
    {
          $sess = Session::has('bamaAdmin');

        return view('admin.index');
    }
    public function banner()
    {
        return view('admin.bannerlist');
    }
  
}
